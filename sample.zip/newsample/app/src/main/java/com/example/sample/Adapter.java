package com.example.sample;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    private List<ModelClass> userList;
    private SelectListener listener;

    public Adapter(List<ModelClass>userList, SelectListener listener){
        this.userList=userList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String cont = userList.get(position).getContact();
        String db =  userList.get(position).getDob();
        String vdid = userList.get(position).getVideourl() ;

        holder.setData(vdid, cont, db, position);


    }

    @Override
    public int getItemCount() {
        return userList.size();
    }


    public class ViewHolder  extends RecyclerView.ViewHolder{

        private TextView conta;
        private TextView dobb;
        private WebView vidd;
        private RelativeLayout description;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            conta = itemView.findViewById(R.id.contact);
            dobb = itemView.findViewById(R.id.dob);
            vidd = itemView.findViewById(R.id.youtube_player_view);
            description = itemView.findViewById(R.id.description);
            vidd.getSettings().setJavaScriptEnabled(true);
        }

        public void setData(String vd, String cont, String db, int position) {
              vidd.loadData(vd,"text/html","utf-8");
              conta .setText(cont);
              dobb.setText(db);

              description.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View view) {
                      listener.itemsended(vd);
                      listener.onItemclicked(userList.get(position));
                  }
              });

        }
    }
}
