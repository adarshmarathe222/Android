package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class searchactivity extends AppCompatActivity {

    Button back,searchitem;
    String redirect;
    EditText videotitle;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchactivity);
        back = findViewById(R.id.back);
        searchitem = findViewById(R.id.searchforvideo);
        videotitle = (EditText) findViewById(R.id.title);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getBaseContext(), homeactivity2.class);
                startActivity(intent);

            }        });

        searchitem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getBaseContext(), homeactivity1.class);
                //name = "dfd";
                name  = videotitle.getText().toString();
                name = name.toLowerCase(Locale.ROOT);
                if(name.isEmpty()){
                    Toast.makeText(searchactivity.this, "Enter The Video Title", Toast.LENGTH_SHORT).show();
                }
                else {
                    intent.putExtra("videoid", name);
                    startActivity(intent);
                }

            }        });
    }
}