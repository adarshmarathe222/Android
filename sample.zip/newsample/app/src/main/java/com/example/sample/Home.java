package com.example.sample;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Home extends Fragment implements SelectListener {

    DBHelper DB;
    EditText name, contact, dob, videoId;
    String redirect;
    Button linkbutton;
    public RelativeLayout relay;

    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<ModelClass> userList;
    Adapter adapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.home, container, false);

        linkbutton = view.findViewById(R.id.linkbutton);
        relay = view.findViewById(R.id.relay);
        linkbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getContext(),MainActivity.class);
                startActivity(intent);

            }        });


        userList = new ArrayList<>();
        DB = new DBHelper(getActivity());
        Cursor res = DB.getdata();

        if(res.getCount()==0){
            Toast.makeText(getActivity(), "No Entry Exists", Toast.LENGTH_SHORT).show();
            return view;
        }

        StringBuffer buffer = new StringBuffer();
        while(res.moveToNext()){


            userList.add(new ModelClass(res.getString(0),res.getString(1),res.getString(2)));



        }

        recyclerView=view.findViewById(R.id.recycler);
        layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new Adapter(userList,this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        return view;
    }


    @Override
    public void itemsended(String send) {
        redirect = send;

    }

    @Override
    public void onItemclicked(ModelClass modelClass) {
        Intent intent = new  Intent(getContext(),vedioview.class);
        intent.putExtra("Sucess", redirect);
        startActivity(intent);

    }


}
