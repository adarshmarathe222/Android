package com.example.sample;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Account extends Fragment {

    EditText userid, password, name, address, emailid, contactno;
    Button signup, signin;
    DBHelper DB;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.account, container, false);


        userid = view.findViewById(R.id.userid);
        password = view.findViewById(R.id.password);
        name = view.findViewById(R.id.name);
        address = view.findViewById(R.id.address);
        emailid = view.findViewById(R.id.emailid);
        contactno = view.findViewById(R.id.contactno);
        signup = view.findViewById(R.id.signup);
        signin = view.findViewById(R.id.signin);

        DB = new DBHelper(getActivity());
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getActivity(), loginactivity.class);
                startActivity(intent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user= userid.getText().toString();
                String pass= password.getText().toString();
                String nam= name.getText().toString();
                String addr= address.getText().toString();
                String email=emailid.getText().toString();
                String contact=contactno.getText().toString();


                Boolean users = DB.insertuserdata1(user, pass, nam, addr, email, contact);
                if(users==true) {
                    Toast.makeText(getActivity(), "Account Created", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getContext(), homeactivity2.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(getActivity(), "User Already Existed", Toast.LENGTH_SHORT).show();
            }        });


        return view;
    }
}
