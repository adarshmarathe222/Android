package com.example.sample;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class signupactivity extends AppCompatActivity {
    EditText userid, password, name, address, emailid, contactno;
    Button signup, signin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupactivity);
            userid = findViewById(R.id.userid);
            password = findViewById(R.id.password);
            name = findViewById(R.id.name);
            address = findViewById(R.id.address);
            emailid = findViewById(R.id.emailid);
            contactno = findViewById(R.id.contactno);
            signup = findViewById(R.id.signup);
            signin = findViewById(R.id.signin);
            DB= new DBHelper(this);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getBaseContext(), loginactivity.class);
                startActivity(intent);
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String user= userid.getText().toString();
            String pass= password.getText().toString();
            String nam= name.getText().toString();
            String addr= address.getText().toString();
            String email=emailid.getText().toString();
            String contact=contactno.getText().toString();



                Boolean users = DB.insertuserdata1(user, pass, nam, addr, email, contact);
                if(users==true)
                    Toast.makeText(signupactivity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(signupactivity.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();


            }        });


    }}

