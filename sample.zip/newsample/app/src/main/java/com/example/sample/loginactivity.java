package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class loginactivity extends AppCompatActivity {
     EditText userid,password;
     Button signin;
     TextView signup;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginactivity);
        userid = findViewById(R.id.userid);
        password = findViewById(R.id.password);
        signup = findViewById(R.id.signup);
        signin = findViewById(R.id.signin);
        DB = new DBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getBaseContext(), signupactivity.class);
                startActivity(intent);
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = userid.getText().toString();
                String pass = password.getText().toString();
                Boolean res = DB.getdata2(user,pass);
                if (res == true){
                    Toast.makeText(loginactivity.this, "LogedIn Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new  Intent(getBaseContext(), homeactivity2.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(loginactivity.this, "User Not Exsited", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}