package com.example.sample;

public interface SelectListener {
    void onItemclicked(ModelClass modelClass);
    void itemsended(String send);
}
