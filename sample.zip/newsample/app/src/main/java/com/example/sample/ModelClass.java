package com.example.sample;

public class ModelClass {
    private String contact;
    private String dob;
    private  String videourl;



    ModelClass(String videourl,String contact, String dob){
        this.videourl = videourl;
        this.contact = contact;
        this.dob = dob;


    }
    public String getVideourl(){
        return videourl;
    }
    public String getContact(){
         return contact;
     }
     public String getDob(){
         return dob;
     }

     public  void setVideourl(String videourl){
        this.videourl=videourl;
     }


}

