package com.example.sample;

import static android.graphics.Color.BLUE;
import static android.graphics.Color.GREEN;
import static android.graphics.Color.RED;
import static android.graphics.Color.WHITE;
import static android.graphics.Color.YELLOW;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class vedioview extends AppCompatActivity {
    DBHelper DB;
    ImageButton like, dislike,willwatch,willnotwatch,maybe;
    Button back;
    WebView myWebView;
    TextView contact, dob;
    String videoid;
    String vid, fname, lname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vedioview);
        contact = findViewById(R.id.contact);
        dob = findViewById(R.id.dob);
        myWebView = findViewById(R.id.youtube_player_view);
        back = findViewById(R.id.back);
        like = findViewById(R.id.like);
        dislike = findViewById(R.id.dislike);
        willwatch = findViewById(R.id.willwatch);
        willnotwatch = findViewById(R.id.willnotwatch);
        maybe = findViewById(R.id.maybe);
        Intent iin= getIntent();
        Bundle b = iin.getExtras();

        if(b!=null)
        {
            videoid =(String) b.get("Sucess");
            //Textv.setText(j);
        }


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getBaseContext(), homeactivity2.class);
                startActivity(intent);
            }
        });
        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(vedioview.this, "You Liked This Video", Toast.LENGTH_SHORT).show();
               /* dislike.setBackgroundColor(WHITE);*/
            }
        });

        dislike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(vedioview.this, "You disliked This Video", Toast.LENGTH_SHORT).show();
               /* like.setBackgroundColor(WHITE);*/
            }
        });

        willwatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(vedioview.this, "You will watch this Video", Toast.LENGTH_SHORT).show();


            }
        });

        willnotwatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(vedioview.this, "You will not watch this Video", Toast.LENGTH_SHORT).show();

            }
        });

        maybe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(vedioview.this, "You maybe watch the Video", Toast.LENGTH_SHORT).show();

            }
        });

        DB = new DBHelper(this);
        Cursor res = DB.getdata3(videoid);

        if(res.getCount()==0){




































































































            Toast.makeText(vedioview.this, "Cant Play Video!!!", Toast.LENGTH_SHORT).show();

        }


        StringBuffer buffer = new StringBuffer();
        while(res.moveToNext()){
            vid = res.getString(0);
            fname = res.getString(1);
            lname = res.getString(2);


        }
        myWebView.reload();
        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.loadData(vid, "text/html","utf-8");
        contact.setText(fname);
        dob.setText(lname);
    }
}